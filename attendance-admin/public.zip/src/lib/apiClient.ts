/**
 * src/lib/apiClient.ts
 *
 * The ONLY place in the app that knows about fetch, base URLs and auth tokens.
 *
 * WHY CENTRALISE THIS: components calling fetch directly would each need to
 * remember to attach the token, parse the envelope, and turn a non-2xx status
 * into a thrown error. Forty components means forty chances to forget one.
 * Here it happens once.
 *
 * In Phase 2, when MSW is switched off and a real FastAPI server answers these
 * same URLs, this file does not change at all. That is the whole point of
 * routing every request through it.
 */

import type { ApiError } from '@/contracts/types';

/**
 * Thrown for any non-2xx response. Carries the parsed error body so a form can
 * show per-field messages.
 */
export class ApiException extends Error {
  status: number;
  code: string;
  fields?: Record<string, string>;

  constructor(status: number, body: ApiError | null) {
    super(body?.error?.message ?? `Request failed with status ${status}`);
    this.name = 'ApiException';
    this.status = status;
    this.code = body?.error?.code ?? 'UNKNOWN';
    this.fields = body?.error?.fields;
  }
}

/**
 * The access token lives in a module variable, not localStorage.
 *
 * WHY NOT localStorage: any script running on the page can read it, which
 * makes an XSS bug into a full account takeover. Keeping it in memory means it
 * dies on refresh — in Phase 2 a refresh token in an httpOnly cookie restores
 * the session silently. For Phase 1 you simply log in again after a refresh.
 */
let accessToken: string | null = null;

export function setAccessToken(token: string | null) {
  accessToken = token;
}

export function getAccessToken() {
  return accessToken;
}

type QueryValue = string | number | boolean | undefined | null;

/** Turns { page: 1, search: 'ana', status: undefined } into '?page=1&search=ana'. */
function buildQuery(params?: Record<string, QueryValue>): string {
  if (!params) return '';
  const qs = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    // undefined and null are skipped so optional filters do not become the
    // literal string "undefined" in the URL.
    if (value === undefined || value === null || value === '') continue;
    qs.append(key, String(value));
  }
  const s = qs.toString();
  return s ? `?${s}` : '';
}

async function request<T>(
  method: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE',
  url: string,
  options: { body?: unknown; params?: Record<string, QueryValue> } = {},
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;

  const response = await fetch(url + buildQuery(options.params), {
    method,
    headers,
    body: options.body !== undefined ? JSON.stringify(options.body) : undefined,
  });

  // 204 No Content has no body to parse.
  if (response.status === 204) return undefined as T;

  let payload: unknown = null;
  try {
    payload = await response.json();
  } catch {
    // Body was empty or not JSON. Leave payload null and let the status decide.
  }

  if (!response.ok) {
    throw new ApiException(response.status, payload as ApiError | null);
  }

  return payload as T;
}

export const apiClient = {
  get: <T>(url: string, params?: Record<string, QueryValue>) =>
    request<T>('GET', url, { params }),
  post: <T>(url: string, body?: unknown) => request<T>('POST', url, { body }),
  patch: <T>(url: string, body?: unknown) => request<T>('PATCH', url, { body }),
  put: <T>(url: string, body?: unknown) => request<T>('PUT', url, { body }),
  delete: <T>(url: string) => request<T>('DELETE', url),
};
