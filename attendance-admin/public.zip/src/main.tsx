/**
 * src/main.tsx
 *
 * Entry point. The mock server starts BEFORE React renders — otherwise the
 * first request could fire before the Service Worker is listening and would hit
 * a real 404.
 *
 * PHASE 2 CUTOVER: delete the enableMocking call. That is the entire change.
 * No component, no hook and no URL changes.
 */

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';

async function enableMocking() {
  if (!import.meta.env.DEV) return;
  const { startMockServer } = await import('./mocks/browser');
  return startMockServer();
}

function render() {
  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}

enableMocking()
  .then(render)
  .catch((error) => {
    /**
     * If the worker cannot start, render anyway rather than leaving a blank
     * page — but say so plainly. A white screen sends people hunting through
     * component code for a crash that never happened.
     */
    console.error('[mocks] failed to start:', error);
    document.getElementById('root')!.innerHTML = `
      <div style="font-family:Inter,sans-serif;max-width:520px;margin:80px auto;padding:24px;
                  border:1px solid rgba(0,0,0,.08);border-radius:16px;background:#fff">
        <h1 style="font-size:18px;margin:0 0 8px">The mock server did not start</h1>
        <p style="font-size:13px;color:#71717A;line-height:1.6;margin:0 0 12px">
          Usually a stale service worker after the dev server restarted.
        </p>
        <ol style="font-size:13px;color:#52525B;line-height:1.8;padding-left:18px;margin:0">
          <li>DevTools &rarr; Application &rarr; Service Workers &rarr; Unregister</li>
          <li>Stop the dev server, run <code>npx msw init public/ --save</code></li>
          <li>Start it again and hard-reload with Ctrl+Shift+R</li>
        </ol>
      </div>`;
  });
