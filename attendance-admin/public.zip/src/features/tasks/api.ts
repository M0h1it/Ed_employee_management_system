/**
 * src/features/tasks/api.ts
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '@/lib/apiClient';
import { EP } from '@/contracts/endpoints';
import type {
  Task,
  TaskListParams,
  CreateTaskRequest,
  UpdateTaskRequest,
  Paginated,
  Single,
} from '@/contracts/types';

export function useTasks(params: TaskListParams) {
  return useQuery({
    queryKey: ['tasks', params],
    queryFn: () =>
      apiClient.get<Paginated<Task>>(EP.tasks.list, {
        employeeId: params.employeeId,
        status: params.status,
        priority: params.priority,
        search: params.search,
        page: params.page,
        pageSize: params.pageSize,
      }),
    placeholderData: (previous) => previous,
  });
}

export function useCreateTask() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: CreateTaskRequest) =>
      apiClient.post<Single<Task>>(EP.tasks.list, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tasks'] }),
  });
}

export function useUpdateTask() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: UpdateTaskRequest }) =>
      apiClient.patch<Single<Task>>(EP.tasks.detail(id), body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tasks'] }),
  });
}

export function useCompleteTask() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => apiClient.patch<Single<Task>>(EP.tasks.complete(id)),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tasks'] }),
  });
}
