/**
 * src/App.tsx
 *
 * Providers wrap the router. Order matters: QueryClientProvider must sit above
 * anything using a query hook, and the router sits inside it because the login
 * mutation calls useNavigate.
 *
 * ConfirmProvider and ToastProvider sit at the top so any component, at any
 * depth, can call useConfirm() or useToast() without threading props down.
 */

import { QueryClientProvider } from '@tanstack/react-query';
import { RouterProvider } from 'react-router-dom';
import { queryClient } from '@/lib/queryClient';
import { router } from '@/routes';
import { ConfirmProvider } from '@/components/common/ConfirmDialog';
import { ToastProvider } from '@/components/common/Toast';

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <ConfirmProvider>
          <RouterProvider router={router} />
        </ConfirmProvider>
      </ToastProvider>
    </QueryClientProvider>
  );
}
