import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    // Lets you write `@/contracts/types` instead of '../../../contracts/types'.
    // This must be mirrored in tsconfig.app.json or the editor will complain
    // even though the build works.
    alias: { '@': path.resolve(__dirname, './src') },
  },
  server: { port: 5173 },
});
