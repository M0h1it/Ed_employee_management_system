/**
 * src/features/settings/api.ts
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '@/lib/apiClient';
import { EP } from '@/contracts/endpoints';
import type {
  OrgSettings,
  UpdateProfileRequest,
  ChangePasswordRequest,
  Employee,
  Single,
} from '@/contracts/types';

export function useOrgSettings() {
  return useQuery({
    queryKey: ['org-settings'],
    queryFn: () => apiClient.get<Single<OrgSettings>>(EP.org.settings),
  });
}

export function useUpdateOrgSettings() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Partial<OrgSettings>) =>
      apiClient.patch<Single<OrgSettings>>(EP.org.settings, body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['org-settings'] });
      /**
       * Attendance days are DERIVED from punches using these rules, so changing
       * the grace period or shift times changes every past day too. Dropping
       * the attendance cache makes that visible immediately rather than leaving
       * stale figures on screen until the next navigation.
       */
      qc.invalidateQueries({ queryKey: ['attendance'] });
      qc.invalidateQueries({ queryKey: ['dashboard'] });
    },
  });
}

export function useUpdateProfile() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: UpdateProfileRequest) =>
      apiClient.patch<Single<Employee>>(EP.auth.profile, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['employees'] }),
  });
}

export function useChangePassword() {
  return useMutation({
    mutationFn: (body: ChangePasswordRequest) =>
      apiClient.patch<void>(EP.auth.changePassword, body),
  });
}
