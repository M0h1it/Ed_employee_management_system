"""
app/schemas/face.py

Enrolment (admin, authenticated user) and kiosk punch (device-authenticated,
no user token) response shapes. Two different audiences, kept in one file
because they describe the same underlying match/confidence concepts.
"""

from datetime import datetime
from enum import Enum
from uuid import UUID

from pydantic import BaseModel


class EnrolResult(BaseModel):
    employeeId: UUID
    templateCount: int
    qualityScore: float


class KioskOutcome(str, Enum):
    match = "MATCH"
    unsure = "UNSURE"
    no_match = "NO_MATCH"
    liveness_failed = "LIVENESS_FAILED"


class KioskPunchResult(BaseModel):
    outcome: KioskOutcome
    employeeId: UUID | None = None
    employeeName: str | None = None
    photoUrl: str | None = None
    direction: str | None = None          # "IN" | "OUT"
    confidence: float | None = None
    punchedAt: datetime | None = None
    message: str


class PinPunchResult(BaseModel):
    employeeId: UUID
    employeeName: str
    direction: str
    punchedAt: datetime
    message: str