"""
app/api/v1/org.py

Reference data: departments and shifts.

Read-only for now, and available to anyone signed in — a filter dropdown needs
the department list, and the names are not sensitive. Creating departments
arrives with the settings screen.
"""

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import Actor, get_current_actor
from app.core.db import get_session
from app.models import Department, Shift
from app.schemas.common import Single
from app.schemas.employee import DepartmentOut, ShiftOut

router = APIRouter(tags=["org"])


@router.get("/departments", response_model=Single[list[DepartmentOut]])
async def list_departments(
    _: Actor = Depends(get_current_actor),
    session: AsyncSession = Depends(get_session),
):
    rows = (await session.execute(select(Department).order_by(Department.name))).scalars().all()
    return Single(data=[DepartmentOut.model_validate(d) for d in rows])


@router.get("/shifts", response_model=Single[list[ShiftOut]])
async def list_shifts(
    _: Actor = Depends(get_current_actor),
    session: AsyncSession = Depends(get_session),
):
    rows = (await session.execute(select(Shift).order_by(Shift.name))).scalars().all()
    return Single(
        data=[
            ShiftOut(
                id=s.id,
                name=s.name,
                startTime=s.start_time.strftime("%H:%M"),
                endTime=s.end_time.strftime("%H:%M"),
                graceMinutes=s.grace_minutes,
                minHours=float(s.min_hours),
            )
            for s in rows
        ]
    )
