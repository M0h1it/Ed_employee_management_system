"""${message}

Revision ID: ${up_revision}
Revises: ${down_revision | comma,n}
Create Date: ${create_date}
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# Autogenerate writes `pgvector.sqlalchemy.vector.VECTOR(...)` for the face
# embedding column but does not add the import for it, so a generated migration
# fails with NameError the first time it runs. Importing it in the template
# means every migration from here on is correct without anyone remembering.
import pgvector.sqlalchemy
${imports if imports else ""}

revision: str = ${repr(up_revision)}
down_revision: Union[str, None] = ${repr(down_revision)}
branch_labels: Union[str, Sequence[str], None] = ${repr(branch_labels)}
depends_on: Union[str, Sequence[str], None] = ${repr(depends_on)}


def upgrade() -> None:
    ${upgrades if upgrades else "pass"}


def downgrade() -> None:
    ${downgrades if downgrades else "pass"}
